from setuptools import setup

setup(
    name='ainaSeleniumTools',
    version='0.0.1',
    description='a pip-installable package ainaSeleniumTools contient des fonction pratiques',
    license='MIT',
    packages=['ainaSeleniumTools'],
    author='Aina KIKI-SAGBE',
    author_email='aina.kiki.sagbe@gmail.com',
    keywords=['845JGtdv!'],
    url='https://github.com/AinaKIKISAGBE/hellostackoverflow',
    zip_safe=True
)
