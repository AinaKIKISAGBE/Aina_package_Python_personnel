# -*- coding: utf-8 -*-
"""
Created on Sun Nov 27 18:15:03 2022

@author: ksami
"""

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from pygame import mixer  # Load the popular external library
import datetime
import time


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select


from webdriver_manager.firefox import GeckoDriverManager

from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import json
from selenium.webdriver.common.action_chains import ActionChains


def clicker(url_select_coche, time_sleep_i, driver):
    #url_select_coche = "#onetrust-reject-all-handler"
    element = driver.find_element_by_css_selector(url_select_coche)
    #element.location_once_scrolled_into_view
    driver.execute_script('arguments[0].scrollIntoView({block: "center", inline: "center"})', element)
    time.sleep(2)
    element.click()
    time.sleep(time_sleep_i)


def sender_key(url_select, value_send, time_sleep_i, driver):
    #♥url_select = "#email"
    element = driver.find_element_by_css_selector(url_select)
    #element.location_once_scrolled_into_view
    driver.execute_script('arguments[0].scrollIntoView({block: "center", inline: "center"})', element)
    time.sleep(2)
    element.clear()
    element.send_keys(value_send)
    time.sleep(time_sleep_i)


def select_liste(url_parent ,list_url, value_chercher,option_search, driver):
    wait = WebDriverWait(driver, 3)
    wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "{}".format(url_parent)))).click()
    time.sleep(2)
    wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "{}".format(list_url))))
    visible_options = driver.find_elements_by_css_selector("{}".format(list_url))
    #option =visible_options[7] 
    #dir(option) 
    #option.text 
    for option in visible_options:
        try :
            code_text = 'if str("{value_chercher}").lower() in str({option_search}).lower() : driver.execute_script("arguments[0].click();", option)'.format(value_chercher = value_chercher, option_search=option_search )
            exec(code_text)
        except Exception :
            pass
    time.sleep(3)

